const state = {
  products: [],
  featured: [],
  settings: {},
  category: 'all',
  search: '',
  sort: 'featured',
  cart: JSON.parse(localStorage.getItem('hlp_cart') || '[]'),
  user: null,
  catalogLimit: 48
};

const categoryLabels = {
  smartphones: 'Smartphones',
  consoles: 'Consoles & Games',
  hardware: 'Hardware & PC',
  notebooks: 'Notebooks',
  audio: 'Áudio',
  smartwatches: 'Smartwatches',
  eletronicos: 'Eletrônicos'
};
const money = (value) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(Number(value || 0));
const moneyUsd = (value) => `U$ ${new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(value || 0))}`;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const escapeHTML = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[char]));

async function api(url, options = {}) {
  const response = await fetch(url, { credentials: 'include', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }, ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Não foi possível concluir a operação.');
  return data;
}

function showToast(message) {
  const toast = $('#toast');
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove('show'), 3600);
}

function productCard(product) {
  const discount = product.oldPrice > product.pricePix ? Math.round((1 - product.pricePix / product.oldPrice) * 100) : 0;
  const image = product.image ? `<img src="${escapeHTML(product.image)}" alt="${escapeHTML(product.name)}" loading="lazy">` : `<span class="product-icon">${escapeHTML(product.icon || '◈')}</span>`;
  const unavailable = product.stock <= 0;
  const dollarRate = Number(state.settings.dollarRate || 5.10);
  const usdPrice = product.pricePix / dollarRate;
  return `<article class="product-card">
    <div class="product-media" style="--product-color:${escapeHTML(product.color || '#1e293b')}">${image}<span class="product-badge">${escapeHTML(product.badge || categoryLabels[product.category] || 'HLP')}</span><span class="product-stock">${unavailable ? 'Disponibilidade a confirmar' : `${product.stock} em estoque`}</span></div>
    <div class="product-info"><p class="product-category">${escapeHTML(categoryLabels[product.category] || product.category)}</p><h3 class="product-name">${escapeHTML(product.name)}</h3><p class="product-description">${escapeHTML(product.description)}</p><div class="price-row"><div>${product.oldPrice > product.pricePix ? `<span class="old-price">${money(product.oldPrice)}</span>` : ''}<strong class="usd-price">${moneyUsd(usdPrice)}</strong><strong class="price">${money(product.pricePix)}</strong><span class="pix-label">BRL • condição no PIX</span></div>${discount ? `<strong class="discount">-${discount}%</strong>` : ''}</div><button class="add-product" data-add="${escapeHTML(product.id)}" ${unavailable ? 'disabled' : ''}>${unavailable ? 'Aguardando confirmação' : 'Adicionar à sacola'} <span>${unavailable ? '—' : '＋'}</span></button></div>
  </article>`;
}

function renderProducts(target, products) {
  const element = $(target);
  if (!products.length) {
    element.innerHTML = '<div class="loading-state">Nenhum produto encontrado para estes filtros.</div>';
    return;
  }
  element.innerHTML = products.map(productCard).join('');
}

function sortProducts(products) {
  const output = [...products];
  if (state.sort === 'priceAsc') output.sort((a, b) => a.pricePix - b.pricePix);
  if (state.sort === 'priceDesc') output.sort((a, b) => b.pricePix - a.pricePix);
  if (state.sort === 'discount') output.sort((a, b) => ((b.oldPrice - b.pricePix) / b.oldPrice) - ((a.oldPrice - a.pricePix) / a.oldPrice));
  return output;
}

function renderCatalog() {
  const filtered = state.products.filter((product) => state.category === 'all' || product.category === state.category).filter((product) => !state.search || `${product.name} ${product.description}`.toLowerCase().includes(state.search.toLowerCase()));
  const sorted = sortProducts(filtered);
  renderProducts('#catalog-grid', sorted.slice(0, state.catalogLimit));
  $('#catalog-count').textContent = filtered.length;
  const more = $('#catalog-more');
  if (more) {
    more.hidden = sorted.length <= state.catalogLimit;
    more.textContent = `Carregar mais produtos (${Math.min(state.catalogLimit, sorted.length)} de ${sorted.length})`;
  }
}

function resetCatalogLimit() {
  state.catalogLimit = 48;
  renderCatalog();
}

function renderFeatured() {
  renderProducts('#featured-grid', state.featured.slice(0, 4));
}

function saveCart() {
  localStorage.setItem('hlp_cart', JSON.stringify(state.cart));
  renderCart();
}

function cartDetails() {
  return state.cart.map((line) => {
    const product = state.products.find((item) => item.id === line.id) || state.featured.find((item) => item.id === line.id);
    return product ? { ...line, product, quantity: Math.max(1, Math.min(line.quantity, product.stock || 1)) } : null;
  }).filter(Boolean);
}

function cartTotal() { return cartDetails().reduce((total, line) => total + line.product.pricePix * line.quantity, 0); }

function renderCart() {
  const items = cartDetails();
  const count = items.reduce((total, line) => total + line.quantity, 0);
  $('#cart-count').textContent = count;
  $('#drawer-count').textContent = count;
  $('#cart-total').textContent = money(cartTotal());
  $('#checkout-button').disabled = !items.length;
  if (!items.length) {
    $('#cart-items').innerHTML = '<div class="empty-cart"><span>▱</span><h3>Seu carrinho está vazio</h3><p>Adicione um produto para começar seu pedido.</p></div>';
    return;
  }
  $('#cart-items').innerHTML = items.map(({ product, quantity }) => `<div class="cart-line"><div class="cart-line-media">${product.image ? `<img src="${escapeHTML(product.image)}" alt="" style="width:100%;height:100%;object-fit:cover">` : escapeHTML(product.icon || '◈')}</div><div><p class="cart-line-name">${escapeHTML(product.name)}</p><span class="cart-line-price">${money(product.pricePix * quantity)}</span><div class="qty-controls"><button data-qty="${escapeHTML(product.id)}" data-delta="-1">−</button><span>${quantity} un.</span><button data-qty="${escapeHTML(product.id)}" data-delta="1">+</button></div></div><button class="remove-line" data-remove="${escapeHTML(product.id)}" aria-label="Remover">×</button></div>`).join('');
}

function openLayer(id) {
  const element = document.getElementById(id);
  element.classList.add('open');
  element.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}
function closeLayer(id) {
  const element = document.getElementById(id);
  if (!element) return;
  element.classList.remove('open');
  element.setAttribute('aria-hidden', 'true');
  if (!document.querySelector('.open')) document.body.style.overflow = '';
}
function closeAllLayers() { ['cart-drawer', 'checkout-modal'].forEach(closeLayer); }

async function loadInitialData() {
  try {
    const [products, featured, settings, testimonials] = await Promise.all([api('/api/products'), api('/api/products?featured=true'), api('/api/settings'), api('/api/testimonials')]);
    state.products = products;
    state.featured = featured;
    state.settings = settings;
    $('#announcement').textContent = settings.announcement || $('#announcement').textContent;
    const instagram = settings.instagram || 'hardwarelowprice__';
    ['#instagram-link', '#footer-instagram'].forEach((selector) => { const link = $(selector); link.href = `https://instagram.com/${encodeURIComponent(instagram)}`; });
    const whatsapp = String(settings.whatsapp || '').replace(/\D/g, '');
    $('#header-dollar-rate').textContent = `R$ ${Number(settings.dollarRate || 5.10).toFixed(2).replace('.', ',')}`;
    ['#faq-whatsapp', '#footer-whatsapp', '#operation-whatsapp'].forEach((selector) => { const link = $(selector); link.href = whatsapp ? `https://wa.me/${whatsapp}` : '#'; link.addEventListener('click', (event) => { if (!whatsapp) { event.preventDefault(); showToast('O WhatsApp ainda será configurado pela equipe.'); } }); });
    const floatingWhatsapp = $('#floating-whatsapp');
    floatingWhatsapp.href = whatsapp ? `https://wa.me/${whatsapp}?text=${encodeURIComponent('Olá, Hardware Low Price! Gostaria de saber mais sobre os produtos.')}` : '#';
    floatingWhatsapp.addEventListener('click', (event) => { if (!whatsapp) { event.preventDefault(); showToast('O WhatsApp ainda será configurado pela equipe.'); } });
    $('#card-installments').textContent = `até ${settings.installments || 12}x${settings.cardFee ? ` +${settings.cardFee}%` : ''}`;
    renderFeatured();
    renderCatalog();
    renderTestimonials(testimonials);
  } catch (error) {
    $('#featured-grid').innerHTML = `<div class="loading-state">Não foi possível carregar o catálogo. ${escapeHTML(error.message)}</div>`;
    $('#catalog-grid').innerHTML = '';
  }
}

function renderTestimonials(testimonials) {
  const section = $('#depoimentos');
  if (!testimonials.length) { section.hidden = true; return; }
  section.hidden = false;
  $('#testimonial-grid').innerHTML = testimonials.map((item) => `<article class="testimonial-card"><div class="stars">${'★'.repeat(Math.max(1, Math.min(5, item.rating || 5)))}</div><p>“${escapeHTML(item.text)}”</p><div class="testimonial-author"><strong>${escapeHTML(item.name)}</strong><small>${escapeHTML(item.city || 'Brasil')}</small></div></article>`).join('');
}

function setCheckoutFeedback(message, success = false) {
  const element = $('#checkout-feedback');
  element.textContent = message;
  element.style.color = success ? 'var(--green)' : 'var(--danger)';
}

function fillCheckoutPrices() {
  const pix = cartTotal();
  const card = pix * (1 + Number(state.settings.cardFee || 0) / 100);
  $('#checkout-pix').textContent = money(pix);
  $('#checkout-card').textContent = money(card);
}

function openCheckout() {
  fillCheckoutPrices();
  closeLayer('cart-drawer');
  openLayer('checkout-modal');
}

async function lookupCep() {
  const cep = $('#cep-input').value.replace(/\D/g, '');
  if (cep.length !== 8) return;
  $('#cep-status').textContent = 'consultando...';
  try {
    const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    const address = await response.json();
    if (address.erro) throw new Error('CEP não encontrado');
    $('#street-input').value = address.logradouro || '';
    $('#neighborhood-input').value = address.bairro || '';
    $('#city-input').value = address.localidade || '';
    $('#state-input').value = address.uf || '';
    $('#cep-status').textContent = 'endereço localizado';
  } catch (_error) {
    $('#cep-status').textContent = 'preencha manualmente';
  }
}

function orderWhatsappUrl(order) {
  const number = String(state.settings.whatsapp || '').replace(/\D/g, '');
  const lines = order.items.map((item) => `• ${item.quantity}x ${item.name} — ${money(item.subtotal)}`);
  const address = `${order.address.street}, ${order.address.number}${order.address.complement ? `, ${order.address.complement}` : ''} — ${order.address.city}/${order.address.state}, CEP ${order.address.cep}`;
  const shippingLabels = { whatsapp: 'Frete a combinar pelo WhatsApp', pac: 'PAC — cotação pelo WhatsApp', sedex: 'SEDEX — cotação pelo WhatsApp' };
  const message = [`Olá, Hardware Low Price! Quero confirmar o pedido *${order.id}*.`, '', `Cliente: ${order.customer.name}`, `WhatsApp: ${order.customer.phone}`, `E-mail: ${order.customer.email}`, '', ...lines, '', `Total dos produtos: *${money(order.total)}* (${order.payment === 'pix' ? 'PIX' : 'cartão'})`, `Frete: ${shippingLabels[order.shipping.method] || 'A combinar'} — valor a confirmar`, `Total informado: *${money(order.total)}* + frete`, `Entrega: ${address}`, '', 'Aguardo a confirmação de disponibilidade, frete e pagamento.'].join('\n');
  return number ? `https://wa.me/${number}?text=${encodeURIComponent(message)}` : '';
}

async function submitCheckout(event) {
  event.preventDefault();
  setCheckoutFeedback('');
  const form = new FormData(event.currentTarget);
  const payload = { items: state.cart, payment: form.get('payment'), shipping: form.get('shipping'), customer: { name: form.get('customerName'), phone: form.get('customerPhone'), email: form.get('customerEmail') }, address: { cep: form.get('cep'), street: form.get('street'), number: form.get('number'), complement: form.get('complement'), neighborhood: form.get('neighborhood'), city: form.get('city'), state: form.get('state') } };
  try {
    const result = await api('/api/orders', { method: 'POST', body: JSON.stringify(payload) });
    const url = orderWhatsappUrl(result.order);
    state.cart = [];
    saveCart();
    closeLayer('checkout-modal');
    if (url) window.open(url, '_blank', 'noopener,noreferrer');
    showToast(url ? `Pedido ${result.order.id} pronto. O WhatsApp foi aberto.` : `Pedido ${result.order.id} criado. O WhatsApp ainda será configurado pela equipe.`);
    await loadInitialData();
  } catch (error) {
    setCheckoutFeedback(error.message);
  }
}

$$('[data-close]').forEach((button) => button.addEventListener('click', () => closeLayer(button.dataset.close)));
$('#cart-button').addEventListener('click', () => openLayer('cart-drawer'));
$('#checkout-button').addEventListener('click', openCheckout);
$('#cep-input').addEventListener('blur', lookupCep);
$('#checkout-form').addEventListener('submit', submitCheckout);

$('#search-input').addEventListener('input', (event) => { state.search = event.target.value; renderCatalog(); });
document.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#search-input').focus(); } if (event.key === 'Escape') closeAllLayers(); });
$$('.category-tab').forEach((tab) => tab.addEventListener('click', () => { $$('.category-tab').forEach((item) => item.classList.remove('active')); tab.classList.add('active'); state.category = tab.dataset.category; resetCatalogLimit(); }));
$$('.category-jump').forEach((button) => button.addEventListener('click', () => { const tab = $(`.category-tab[data-category="${button.dataset.category}"]`); if (tab) tab.click(); $('#catalogo').scrollIntoView({ behavior: 'smooth' }); }));
$('#catalog-more').addEventListener('click', () => { state.catalogLimit += 48; renderCatalog(); });
$('#sort-button').addEventListener('click', () => { const options = ['featured', 'priceAsc', 'priceDesc', 'discount']; const index = options.indexOf(state.sort); state.sort = options[(index + 1) % options.length]; const labels = { featured: 'Ordenar', priceAsc: 'Menor preço', priceDesc: 'Maior preço', discount: 'Maior desconto' }; $('#sort-button').innerHTML = `${labels[state.sort]} <span>⌄</span>`; renderCatalog(); });

document.addEventListener('click', (event) => {
  const add = event.target.closest('[data-add]');
  if (add) {
    const id = add.dataset.add;
    const product = state.products.find((item) => item.id === id) || state.featured.find((item) => item.id === id);
    if (!product || product.stock <= 0) return;
    const line = state.cart.find((item) => item.id === id);
    if (line) line.quantity = Math.min(line.quantity + 1, product.stock); else state.cart.push({ id, quantity: 1 });
    saveCart();
    showToast(`${product.name} foi adicionado ao carrinho.`);
    return;
  }
  const qty = event.target.closest('[data-qty]');
  if (qty) {
    const line = state.cart.find((item) => item.id === qty.dataset.qty);
    const product = state.products.find((item) => item.id === qty.dataset.qty);
    if (!line || !product) return;
    line.quantity += Number(qty.dataset.delta);
    if (line.quantity <= 0) state.cart = state.cart.filter((item) => item.id !== line.id);
    else line.quantity = Math.min(line.quantity, product.stock);
    saveCart();
    return;
  }
  const remove = event.target.closest('[data-remove]');
  if (remove) { state.cart = state.cart.filter((item) => item.id !== remove.dataset.remove); saveCart(); }
});

renderCart();
loadInitialData();
