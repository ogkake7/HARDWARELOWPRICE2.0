#!/usr/bin/env python3
"""Importa produtos públicos da Atacado Connect para o catálogo local da HLP.

As páginas são públicas; nenhuma credencial é salva ou necessária neste importador.
As imagens permanecem nos URLs públicos do CDN da loja de origem para evitar um
pacote local de vários gigabytes. Use --merge-db para atualizar data/db.json.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from html import unescape
from pathlib import Path
from urllib.parse import urljoin
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup

BASE = "https://atacadoconnect.com"
CATEGORIES = {
    "games": "consoles",
    "smartphones": "smartphones",
    "smartphones/smartwatch": "smartwatches",
    "games/consoles": "consoles",
    "eletronicos": "eletronicos",
}
ICON_BY_CATEGORY = {
    "consoles": "◈",
    "smartphones": "⌁",
    "smartwatches": "◉",
    "eletronicos": "✦",
}
HEADERS = {"User-Agent": "HardwareLowPrice-CatalogImporter/1.0"}


def fetch(url: str, attempts: int = 3) -> str:
    last_error = None
    for attempt in range(attempts):
        try:
            request = Request(url, headers=HEADERS)
            with urlopen(request, timeout=45) as response:
                return response.read().decode("utf-8", "ignore")
        except Exception as error:  # noqa: BLE001 - retry remote catalog reads
            last_error = error
            time.sleep(1.5 * (attempt + 1))
    raise RuntimeError(f"Falha ao baixar {url}: {last_error}")


def page_count(html: str) -> int:
    pages = [int(value) for value in re.findall(r"[?&]page=(\d+)", html)]
    return max(pages or [1])


def parse_money(text: str, currency: str) -> float:
    match = re.search(rf"{re.escape(currency)}\s*([\d.]+,\d{{2}})", text)
    if not match:
        return 0.0
    return float(match.group(1).replace(".", "").replace(",", "."))


def clean_title(value: str) -> str:
    return re.sub(r"\s+", " ", unescape(value or "")).strip()[:160]


def parse_page(html: str, source_category: str, source_url: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    target_category = CATEGORIES[source_category]
    products = []
    seen = set()
    for anchor in soup.select('a[href*="/produto/"]'):
        href = anchor.get("href", "")
        match = re.search(r"/(\d+)/?$", href)
        if not match or match.group(1) in seen:
            continue
        product_id = match.group(1)
        title_node = anchor.find(["h2", "h3", "h4"])
        title = clean_title(title_node.get_text(" ", strip=True) if title_node else "")
        if not title:
            continue
        text = clean_title(anchor.get_text(" ", strip=True))
        parts = [part.strip() for part in anchor.get_text("|", strip=True).split("|") if part.strip()]
        brand = parts[2] if len(parts) >= 3 else "Atacado Connect"
        price_usd = parse_money(text, "U$")
        price_brl = parse_money(text, "R$")
        image = ""
        for image_node in anchor.select("img"):
            candidate = image_node.get("src") or image_node.get("data-src") or ""
            if candidate and ("/capa/" in candidate or "/thumb/" in candidate):
                image = urljoin(BASE, candidate)
                break
        if not image or not price_brl:
            continue
        seen.add(product_id)
        products.append({
            "id": f"ac-{product_id}",
            "sourceId": product_id,
            "sourceUrl": urljoin(BASE, href),
            "name": title,
            "category": target_category,
            "description": f"{brand}. Produto listado no catálogo Atacado Connect; disponibilidade e condição confirmadas no WhatsApp.",
            "pricePix": round(price_brl, 2),
            "oldPrice": 0,
            "stock": 1,
            "featured": len(products) < 8,
            "visible": True,
            "badge": brand[:28],
            "icon": ICON_BY_CATEGORY.get(target_category, "◈"),
            "color": "#f4f8f4",
            "image": image,
            "priceUsd": round(price_usd, 2),
            "sourceCategory": source_category,
        })
    return products


def collect_category(source_category: str) -> list[dict]:
    first_url = f"{BASE}/categoria/{source_category}"
    first_html = fetch(first_url)
    total_pages = page_count(first_html)
    urls = [first_url] + [f"{first_url}?page={page}" for page in range(2, total_pages + 1)]
    print(f"{source_category}: {total_pages} páginas", file=sys.stderr, flush=True)
    products: list[dict] = []
    with ThreadPoolExecutor(max_workers=8) as executor:
        futures = {executor.submit(fetch, url): (index, url) for index, url in enumerate(urls, 1)}
        for future in as_completed(futures):
            index, url = futures[future]
            try:
                products.extend(parse_page(future.result(), source_category, url))
            except Exception as error:  # keep other pages importing
                print(f"aviso: {source_category} página {index}: {error}", file=sys.stderr, flush=True)
            if index % 10 == 0 or index == len(urls):
                print(f"{source_category}: {index}/{len(urls)} páginas", file=sys.stderr, flush=True)
    return products


def dedupe(products: list[dict]) -> list[dict]:
    result = {}
    for product in products:
        result[product["sourceId"]] = product
    output = list(result.values())
    for index, product in enumerate(output):
        product["featured"] = index < 12
    return output


def merge_db(products: list[dict], db_path: Path) -> None:
    data = json.loads(db_path.read_text(encoding="utf-8"))
    data["users"] = []
    data["products"] = products
    data.setdefault("settings", {})
    data["settings"]["dollarRate"] = float(data["settings"].get("dollarRate") or 5.10)
    db_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--merge-db", action="store_true", help="substitui o catálogo em data/db.json")
    parser.add_argument("--output", default="data/atacado-catalog.json")
    args = parser.parse_args()
    all_products: list[dict] = []
    for source_category in CATEGORIES:
        all_products.extend(collect_category(source_category))
    products = dedupe(all_products)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps({"source": BASE, "categories": list(CATEGORIES), "products": products}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if args.merge_db:
        merge_db(products, Path("data/db.json"))
    print(json.dumps({"products": len(products), "output": str(output), "merged": args.merge_db}, ensure_ascii=False))


if __name__ == "__main__":
    main()
